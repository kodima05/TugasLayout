# Contoh membuat aplikasi mobile dengan React-Native
# User memasukkan nilai alas dan tinggi, kemudian aplikasi akan menampilkan luas segitiga.
![Alt text](screenshot.png?raw=true "Optional Title")
